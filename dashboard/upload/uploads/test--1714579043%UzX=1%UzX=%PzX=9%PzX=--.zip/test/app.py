import test
import pydoc

pydoc.cli()