""" This module provides functions to convert a PDF to text """

def covert(path):
    """
    Convert the given PDF to text.

    Parameters:
    path (str): The path ot a PDF file

    Returns:
    str: The content of the PDF file
    """
    print("pdf2text")